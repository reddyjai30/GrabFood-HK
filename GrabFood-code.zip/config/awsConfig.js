const { S3Client } = require('@aws-sdk/client-s3');
require('dotenv').config();

const s3Client = new S3Client({
  region: 'ap-south-1',
  credentials: {
    accessKeyId: 'AKIA5EZ3L4FY7FG4BVPU',
    secretAccessKey: '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'
  }
});

module.exports = s3Client;
