const mongoose = require('mongoose');

const adminSettingsSchema = new mongoose.Schema({
    thresholdDistance: { type: Number, required: true }, // in kilometers
    additionalFee: { type: Number, required: true } // additional fee when threshold is exceeded
});

module.exports = mongoose.model('AdminSettings', adminSettingsSchema);
