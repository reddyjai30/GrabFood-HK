const { uploadFileToS3, deleteFileFromS3, updateFileInS3 } = require('../utils/s3Uploader');


//upload
exports.uploadImageToS3 = async (req, res) => {
    if (!req.file) return res.status(400).send('File is required.');
  
    const fileBuffer = req.file.buffer;
    const mimeType = req.file.mimetype;
    const fileName = req.file.originalname;
    const bucketName = process.env.S3_BUCKET_NAME;
  
    try {
      const uploadResult = await uploadFileToS3(fileBuffer, bucketName, fileName, mimeType);
      res.status(200).json({
        message: 'Upload successful',
        imageUrl: uploadResult.Location,
        key: uploadResult.key  // Return the key to the client
      });
    } catch (error) {
      console.error('Upload error:', error);
      res.status(500).json({ message: 'Failed to upload image', error: error.message });
    }
};
  


//delete
exports.deleteImageFromS3 = async (req, res) => {
    const { key } = req.params; // Ensure key is received as a parameter
    try {
      const result = await deleteFileFromS3(process.env.S3_BUCKET_NAME, key);
      res.status(200).json({ message: 'File deleted successfully', details: result });
    } catch (error) {
      res.status(500).json({ message: 'Failed to delete file', error: error.message });
    }
  };
  
  exports.updateImageInS3 = async (req, res) => {
    const key = req.params.key;  // Key for the S3 object
    const file = req.file;       // The new file data from the request
  
    try {
      const result = await updateFileInS3(file.buffer, process.env.S3_BUCKET, key, file.mimetype);
      res.json({ message: 'Image updated successfully', details: result });
    } catch (error) {
      console.error('Error updating image:', error);
      res.status(500).json({ message: 'Failed to update image', error: error.message });
    }
  };